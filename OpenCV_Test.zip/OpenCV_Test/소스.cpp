#include <stdio.h>
#include <stdlib.h>
#include "opencv2/opencv.hpp"
#include "opencv2/highgui.hpp"

using namespace cv;
using namespace std;


int main(void)
{
	Mat img_resize;
	Mat img_origin = imread("input.tif", IMREAD_GRAYSCALE);
	int t = img_origin.at<uchar>(55, 55);
	printf("%d\n", t);
	//printf("%d\n", img_origin.at<uchar>(55, 55));
	//resize(img_origin, img_resize, Size(10000, 10000));

	//imwrite("output.tif", img_origin);
	return 0;
}